"""
使用示例 - RedisVL 语义处理模块

展示如何使用 EmbeddingsCache, SemanticCache, 
SemanticMessageHistory 和 SemanticRouter

运行前请确保:
1. Redis 服务正在运行 (默认: redis://localhost:6379)
2. 已安装依赖: pip install redis sentence-transformers
"""

from SemanticCache import SemanticCache
from SemanticMessageHistory import SemanticMessageHistory
from SemanticRouter import SemanticRouter, Route


def example_semantic_cache():
    """SemanticCache 使用示例"""
    print("=" * 60)
    print("SemanticCache 示例 - LLM 响应缓存")
    print("=" * 60)
    
    # 初始化语义缓存
    cache = SemanticCache(
        name="llmcache",
        distance_threshold=0.1,  # 语义距离阈值
        ttl=360,                  # 缓存过期时间（秒）
        redis_url="redis://localhost:6379"
    )
    
    # 存储 LLM 响应
    cache.store(
        prompt="What is the capital city of France?",
        response="Paris is the capital city of France.",
        metadata={"city": "Paris", "country": "France"}
    )
    
    # 检查缓存（使用相似问题）
    results = cache.check(prompt="What is France's capital city?")
    
    if results:
        print(f"✅ 缓存命中!")
        print(f"   原始问题: {results[0]['prompt']}")
        print(f"   缓存响应: {results[0]['response']}")
        print(f"   语义距离: {results[0]['distance']:.4f}")
    else:
        print("❌ 缓存未命中")
    
    # 检查缓存（使用不同问题）
    results = cache.check(prompt="What is Python?")
    if not results:
        print("✅ 不同问题正确地未命中缓存")
    
    cache.disconnect()
    print()


def example_message_history():
    """SemanticMessageHistory 使用示例"""
    print("=" * 60)
    print("SemanticMessageHistory 示例 - 对话记忆")
    print("=" * 60)
    
    # 初始化消息历史
    history = SemanticMessageHistory(
        name="chat-history",
        session_tag="user123",
        distance_threshold=0.3,
        redis_url="redis://localhost:6379"
    )
    
    # 添加对话消息
    history.add_message({"role": "user", "content": "Hello, how are you?"})
    history.add_message({"role": "llm", "content": "I'm doing great, thanks!"})
    history.add_message({"role": "user", "content": "What's the weather today?"})
    history.add_message({"role": "llm", "content": "It's sunny and 25°C."})
    history.add_message({
        "role": "user", 
        "content": "Should I bring an umbrella?",
        "metadata": {"topic": "weather"}
    })
    
    # 获取最近消息
    print("📝 最近 3 条消息:")
    recent = history.get_recent(top_k=3)
    for msg in recent:
        print(f"   [{msg['role']}] {msg['content']}")
    
    # 语义搜索相关消息
    print("\n🔍 语义搜索 'rain' 相关消息:")
    relevant = history.get_relevant(
        prompt="rain or precipitation",
        top_k=2,
        distance_threshold=0.5
    )
    for msg in relevant:
        print(f"   [{msg['role']}] {msg['content']} (distance: {msg.get('distance', 0):.4f})")
    
    # 获取消息统计
    print(f"\n📊 消息总数: {history.count()}")
    
    history.disconnect()
    print()


def example_semantic_router():
    """SemanticRouter 使用示例"""
    print("=" * 60)
    print("SemanticRouter 示例 - 智能路由")
    print("=" * 60)
    
    # 定义路由
    routes = [
        Route(
            name="greeting",
            references=["hello", "hi", "hey", "good morning", "good afternoon"],
            metadata={"type": "greeting", "priority": 1}
        ),
        Route(
            name="farewell",
            references=["bye", "goodbye", "see you", "take care"],
            metadata={"type": "farewell", "priority": 1}
        ),
        Route(
            name="weather",
            references=[
                "weather", "temperature", "rain", "sunny", 
                "forecast", "climate", "hot", "cold"
            ],
            metadata={"type": "information", "priority": 2}
        ),
        Route(
            name="coding",
            references=[
                "code", "programming", "python", "javascript",
                "function", "bug", "debug", "algorithm"
            ],
            metadata={"type": "technical", "priority": 2}
        ),
    ]
    
    # 初始化路由器
    router = SemanticRouter(
        name="topic-router",
        routes=routes,
        redis_url="redis://localhost:6379"
    )
    
    # 测试路由
    test_queries = [
        "Hi there, good morning!",
        "Goodbye, see you later!",
        "What's the weather like today?",
        "I have a bug in my Python code",
        "Tell me a joke"
    ]
    
    print("🧭 路由测试:")
    for query in test_queries:
        result = router(query)
        if result.name:
            print(f"   '{query}' → {result.name} (distance: {result.distance:.4f})")
        else:
            print(f"   '{query}' → 无匹配路由")
    
    # 动态添加新路由
    print("\n➕ 添加新路由 'joke':")
    router.add_route_references(
        "joke",
        ["tell me a joke", "make me laugh", "funny story", "humor"]
    )
    
    result = router("Can you make me laugh?")
    print(f"   'Can you make me laugh?' → {result.name}")
    
    router.disconnect()
    print()


def example_embeddings_cache():
    """EmbeddingsCache 使用示例"""
    print("=" * 60)
    print("EmbeddingsCache 示例 - 向量缓存")
    print("=" * 60)
    
    from EmbeddingsCache import EmbeddingsCache
    
    # 初始化嵌入缓存
    cache = EmbeddingsCache(
        name="embeddings",
        ttl=3600,  # 1小时
        redis_url="redis://localhost:6379"
    )
    
    # 存储向量
    text = "What is machine learning?"
    vector = [0.1] * 384  # 示例向量
    
    cache.set(text, vector, metadata={"source": "user_query"})
    
    # 获取向量
    cached = cache.get(text)
    if cached:
        print(f"✅ 缓存命中: '{text}'")
    else:
        print("❌ 缓存未命中")
    
    # 获取统计
    stats = cache.get_stats()
    print(f"\n📊 缓存统计:")
    print(f"   名称: {stats.get('name')}")
    print(f"   条目数: {stats.get('total_entries')}")
    print(f"   总大小: {stats.get('total_size_bytes')} bytes")
    
    cache.disconnect()
    print()


def main():
    """运行所有示例"""
    print("\n🚀 RedisVL 语义处理模块示例\n")
    
    try:
        example_semantic_cache()
        example_message_history()
        example_semantic_router()
        example_embeddings_cache()
        
        print("=" * 60)
        print("✅ 所有示例运行完成!")
        print("=" * 60)
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        print("请确保 Redis 服务正在运行")
        raise


if __name__ == "__main__":
    main()
