"""
SemanticRouter - 语义路由模块

基于语义相似度的智能路由系统，用于将用户查询路由到
不同的处理逻辑或 Agent。运行在 Redis 中，高性能决策。

基于 Redis Vector Library (RedisVL) 设计
"""

from typing import Any, Dict, List, Optional, Union
from enum import Enum
from datetime import datetime
from pydantic import BaseModel, Field
import json
import yaml
import uuid


class DistanceAggregationMethod(str, Enum):
    """距离聚合方法枚举"""
    AVG = 'avg'  # 计算平均距离
    MIN = 'min'  # 使用最小距离
    SUM = 'sum'  # 计算距离总和


class RouteMatch(BaseModel):
    """路由匹配结果模型"""
    name: Optional[str] = None
    distance: Optional[float] = None


class RoutingConfig(BaseModel):
    """路由配置模型"""
    max_k: int = Field(default=1, gt=0)
    aggregation_method: DistanceAggregationMethod = DistanceAggregationMethod.AVG


class Route(BaseModel):
    """路由定义模型"""
    name: str
    references: List[str]
    metadata: Dict[str, Any] = {}
    distance_threshold: float = Field(default=0.5, gt=0, le=2)


class SemanticRouter:
    """
    语义路由器类
    
    根据用户输入的语义，将查询路由到最匹配的路由（topic）。
    支持多个参考短语，可动态添加和更新路由。
    
    Attributes:
        name: 路由器名称
        routes: 路由列表
        vectorizer: 向量化器
        routing_config: 路由配置
    """
    
    def __init__(
        self,
        name: str,
        routes: List[Route],
        vectorizer=None,
        routing_config: Optional[RoutingConfig] = None,
        redis_client=None,
        redis_url: str = "redis://localhost:6379",
        overwrite: bool = False,
        connection_kwargs: Dict[str, Any] = {},
        **kwargs
    ):
        """
        初始化语义路由器
        
        Args:
            name: 路由器名称
            routes: Route 对象列表
            vectorizer: 向量化器
            routing_config: 路由配置
            redis_client: Redis 客户端
            redis_url: Redis 连接 URL
            overwrite: 是否覆盖已有索引
            connection_kwargs: Redis 连接参数
        """
        self.name = name
        self.routes = routes
        self.routing_config = routing_config or RoutingConfig()
        self.overwrite = overwrite
        self.redis_url = redis_url
        self.connection_kwargs = connection_kwargs
        self.vectorizer = vectorizer
        self._redis_client = redis_client
        
        # 缓存键前缀
        self._prefix = f"semantic_router:{name}"
        self._route_prefix = f"{self._prefix}:route"
        
        # 初始化
        if self._redis_client is None:
            self._init_redis_client()
        
        if self.vectorizer is None:
            self._init_vectorizer()
        
        # 初始化路由索引
        self._initialize_routes()
    
    def _init_redis_client(self):
        """初始化 Redis 客户端"""
        try:
            import redis
            self._redis_client = redis.from_url(
                self.redis_url,
                decode_responses=True,
                **self.connection_kwargs
            )
        except ImportError:
            raise ImportError("请安装 redis 包: pip install redis")
    
    def _init_vectorizer(self):
        """初始化向量化器"""
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer('all-MiniLM-L6-v2')
            self.vectorizer = self._embed_text
        except ImportError:
            raise ImportError("请安装 sentence-transformers 包: pip install sentence-transformers")
    
    def _embed_text(self, text: str) -> List[float]:
        """将文本转换为向量"""
        if hasattr(self, '_model'):
            embedding = self._model.encode(text)
            return embedding.tolist()
        raise RuntimeError("向量化器未初始化")
    
    def _generate_id(self) -> str:
        """生成唯一 ID"""
        return str(uuid.uuid4())
    
    def _initialize_routes(self) -> None:
        """初始化所有路由的向量索引"""
        for route in self.routes:
            for ref in route.references:
                vector = self.vectorizer(ref)
                self._store_route_reference(route.name, ref, vector, route.distance_threshold)
    
    def _store_route_reference(
        self,
        route_name: str,
        reference: str,
        vector: List[float],
        threshold: float
    ) -> str:
        """存储路由参考向量"""
        ref_id = self._generate_id()
        key = f"{self._route_prefix}:{route_name}:{ref_id}"
        
        data = {
            'id': ref_id,
            'route_name': route_name,
            'reference': reference,
            'vector': vector,
            'threshold': threshold,
            'created_at': datetime.now().isoformat()
        }
        
        self._redis_client.set(key, json.dumps(data))
        
        # 添加到路由索引
        self._redis_client.sadd(f"{self._prefix}:routes", route_name)
        
        return key
    
    def __call__(self, statement: Optional[str] = None, vector: Optional[List[float]] = None) -> RouteMatch:
        """
        执行路由（调用方式）
        
        Args:
            statement: 输入语句
            vector: 预计算的向量
            
        Returns:
            路由匹配结果
        """
        return self.route(statement=statement, vector=vector)
    
    def route(
        self,
        statement: Optional[str] = None,
        vector: Optional[List[float]] = None
    ) -> RouteMatch:
        """
        将输入路由到最匹配的路由
        
        Args:
            statement: 输入语句
            vector: 预计算的向量
            
        Returns:
            路由匹配结果
        """
        if statement is None and vector is None:
            raise ValueError("必须提供 statement 或 vector")
        
        # 获取向量
        if vector is None:
            vector = self.vectorizer(statement)
        
        # 搜索最佳匹配
        results = self._search_routes(vector)
        
        if results:
            # 按距离排序
            results.sort(key=lambda x: x['distance'])
            best = results[0]
            
            # 检查是否在阈值内
            route = self.get(best['route_name'])
            if route and best['distance'] <= route.distance_threshold:
                return RouteMatch(name=best['route_name'], distance=best['distance'])
        
        return RouteMatch(name=None, distance=None)
    
    def route_many(
        self,
        statement: Optional[str] = None,
        vector: Optional[List[float]] = None,
        max_k: Optional[int] = None,
        distance_threshold: Optional[float] = None,
        aggregation_method: Optional[DistanceAggregationMethod] = None
    ) -> List[RouteMatch]:
        """
        返回多个路由匹配
        
        Args:
            statement: 输入语句
            vector: 预计算的向量
            max_k: 最大返回数量
            distance_threshold: 距离阈值
            aggregation_method: 聚合方法
            
        Returns:
            路由匹配列表
        """
        if statement is None and vector is None:
            raise ValueError("必须提供 statement 或 vector")
        
        # 获取向量
        if vector is None:
            vector = self.vectorizer(statement)
        
        k = max_k or self.routing_config.max_k
        method = aggregation_method or self.routing_config.aggregation_method
        
        # 搜索所有匹配
        all_results = self._search_routes(vector, with_aggregation=True)
        
        # 按路由聚合
        route_distances = {}
        for result in all_results:
            route_name = result['route_name']
            distance = result['distance']
            
            if route_name not in route_distances:
                route_distances[route_name] = []
            route_distances[route_name].append(distance)
        
        # 聚合距离
        aggregated = []
        for route_name, distances in route_distances.items():
            if method == DistanceAggregationMethod.AVG:
                agg_distance = sum(distances) / len(distances)
            elif method == DistanceAggregationMethod.MIN:
                agg_distance = min(distances)
            else:  # SUM
                agg_distance = sum(distances)
            
            # 检查阈值
            route = self.get(route_name)
            threshold = distance_threshold or (route.distance_threshold if route else 0.5)
            
            if agg_distance <= threshold:
                aggregated.append(RouteMatch(name=route_name, distance=agg_distance))
        
        # 排序并返回 top_k
        aggregated.sort(key=lambda x: x.distance)
        return aggregated[:k]
    
    def _search_routes(
        self,
        vector: List[float],
        with_aggregation: bool = False
    ) -> List[Dict[str, Any]]:
        """
        搜索路由
        
        Args:
            vector: 查询向量
            with_aggregation: 是否返回所有匹配用于聚合
            
        Returns:
            匹配结果列表
        """
        results = []
        route_names = self._redis_client.smembers(f"{self._prefix}:routes")
        
        for route_name in route_names:
            pattern = f"{self._route_prefix}:{route_name}:*"
            keys = list(self._redis_client.scan_iter(match=pattern))
            
            for key in keys:
                data = self._redis_client.get(key)
                if data:
                    entry = json.loads(data)
                    stored_vector = entry.get('vector', [])
                    distance = self._cosine_distance(vector, stored_vector)
                    
                    results.append({
                        'route_name': route_name,
                        'reference': entry['reference'],
                        'distance': distance
                    })
                    
                    if not with_aggregation:
                        break  # 每个路由只取最佳匹配
        
        return results
    
    def _cosine_distance(self, v1: List[float], v2: List[float]) -> float:
        """计算余弦距离"""
        if not v1 or not v2 or len(v1) != len(v2):
            return 2.0
        
        dot_product = sum(a * b for a, b in zip(v1, v2))
        norm1 = sum(a * a for a in v1) ** 0.5
        norm2 = sum(b * b for b in v2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 2.0
        
        similarity = dot_product / (norm1 * norm2)
        return 1.0 - similarity
    
    def add_route_references(
        self,
        route_name: str,
        references: Union[str, List[str]]
    ) -> List[str]:
        """
        添加路由参考
        
        Args:
            route_name: 路由名称
            references: 参考文本或列表
            
        Returns:
            添加的参考键列表
        """
        if isinstance(references, str):
            references = [references]
        
        keys = []
        route = self.get(route_name)
        threshold = route.distance_threshold if route else 0.5
        
        for ref in references:
            vector = self.vectorizer(ref)
            key = self._store_route_reference(route_name, ref, vector, threshold)
            keys.append(key)
        
        return keys
    
    def delete_route_references(
        self,
        route_name: str = '',
        reference_ids: List[str] = [],
        keys: List[str] = []
    ) -> int:
        """
        删除路由参考
        
        Args:
            route_name: 路由名称
            reference_ids: 参考 ID 列表
            keys: 完整的键列表
            
        Returns:
            删除的数量
        """
        keys_to_delete = []
        
        if reference_ids:
            keys_to_delete.extend([
                f"{self._route_prefix}:{route_name}:{ref_id}"
                for ref_id in reference_ids
            ])
        
        if keys:
            keys_to_delete.extend(keys)
        
        if keys_to_delete:
            return self._redis_client.delete(*keys_to_delete)
        return 0
    
    def get_route_references(
        self,
        route_name: str = '',
        reference_ids: List[str] = [],
        keys: List[str] = []
    ) -> List[Dict[str, Any]]:
        """
        获取路由参考
        
        Args:
            route_name: 路由名称
            reference_ids: 参考 ID 列表
            keys: 完整的键列表
            
        Returns:
            参考对象列表
        """
        all_keys = []
        
        if reference_ids:
            all_keys.extend([
                f"{self._route_prefix}:{route_name}:{ref_id}"
                for ref_id in reference_ids
            ])
        
        if keys:
            all_keys.extend(keys)
        
        results = []
        for key in all_keys:
            data = self._redis_client.get(key)
            if data:
                entry = json.loads(data)
                results.append({
                    'id': entry['id'],
                    'route_name': entry['route_name'],
                    'reference': entry['reference'],
                    'threshold': entry.get('threshold')
                })
        
        return results
    
    def get(self, route_name: str) -> Optional[Route]:
        """
        获取路由
        
        Args:
            route_name: 路由名称
            
        Returns:
            Route 对象或 None
        """
        for route in self.routes:
            if route.name == route_name:
                return route
        return None
    
    def remove_route(self, route_name: str) -> None:
        """
        移除路由
        
        Args:
            route_name: 路由名称
        """
        # 删除所有参考
        pattern = f"{self._route_prefix}:{route_name}:*"
        keys = list(self._redis_client.scan_iter(match=pattern))
        if keys:
            self._redis_client.delete(*keys)
        
        # 从路由集合中移除
        self._redis_client.srem(f"{self._prefix}:routes", route_name)
        
        # 从内存中移除
        self.routes = [r for r in self.routes if r.name != route_name]
    
    def update_route_thresholds(self, route_thresholds: Dict[str, float]) -> None:
        """
        更新路由阈值
        
        Args:
            route_thresholds: 路由名称到阈值的映射
        """
        for route in self.routes:
            if route.name in route_thresholds:
                route.distance_threshold = route_thresholds[route.name]
    
    def update_routing_config(self, routing_config: RoutingConfig) -> None:
        """
        更新路由配置
        
        Args:
            routing_config: 新的路由配置
        """
        self.routing_config = routing_config
    
    def clear(self) -> None:
        """清空所有路由"""
        pattern = f"{self._route_prefix}:*"
        keys = list(self._redis_client.scan_iter(match=pattern))
        if keys:
            self._redis_client.delete(*keys)
        
        self._redis_client.delete(f"{self._prefix}:routes")
    
    def delete(self) -> None:
        """删除整个语义路由器"""
        self.clear()
        self._redis_client.delete(self._prefix)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典
        
        Returns:
            字典表示
        """
        return {
            'name': self.name,
            'routes': [
                {
                    'name': r.name,
                    'references': r.references,
                    'metadata': r.metadata,
                    'distance_threshold': r.distance_threshold
                }
                for r in self.routes
            ],
            'vectorizer': None,  # 无法序列化
            'routing_config': {
                'max_k': self.routing_config.max_k,
                'aggregation_method': self.routing_config.aggregation_method.value
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], **kwargs) -> 'SemanticRouter':
        """
        从字典创建
        
        Args:
            data: 字典数据
            **kwargs: 其他参数
            
        Returns:
            SemanticRouter 实例
        """
        routes = [
            Route(
                name=r['name'],
                references=r['references'],
                metadata=r.get('metadata', {}),
                distance_threshold=r.get('distance_threshold', 0.5)
            )
            for r in data.get('routes', [])
        ]
        
        config_data = data.get('routing_config', {})
        routing_config = RoutingConfig(
            max_k=config_data.get('max_k', 1),
            aggregation_method=DistanceAggregationMethod(
                config_data.get('aggregation_method', 'avg')
            )
        )
        
        return cls(
            name=data['name'],
            routes=routes,
            routing_config=routing_config,
            **kwargs
        )
    
    def to_yaml(self, file_path: str, overwrite: bool = True) -> None:
        """
        导出为 YAML 文件
        
        Args:
            file_path: 文件路径
            overwrite: 是否覆盖
        """
        import os
        if os.path.exists(file_path) and not overwrite:
            raise FileExistsError(f"文件 {file_path} 已存在")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False)
    
    @classmethod
    def from_yaml(cls, file_path: str, **kwargs) -> 'SemanticRouter':
        """
        从 YAML 文件创建
        
        Args:
            file_path: 文件路径
            **kwargs: 其他参数
            
        Returns:
            SemanticRouter 实例
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        return cls.from_dict(data, **kwargs)
    
    @classmethod
    def from_existing(
        cls,
        name: str,
        redis_client=None,
        redis_url: str = "redis://localhost:6379",
        **kwargs
    ) -> 'SemanticRouter':
        """
        从现有索引创建
        
        Args:
            name: 路由器名称
            redis_client: Redis 客户端
            redis_url: Redis 连接 URL
            **kwargs: 其他参数
            
        Returns:
            SemanticRouter 实例
        """
        prefix = f"semantic_router:{name}"
        
        try:
            import redis
            client = redis_client or redis.from_url(redis_url, decode_responses=True)
            
            # 获取所有路由
            route_names = client.smembers(f"{prefix}:routes")
            
            routes = []
            for route_name in route_names:
                pattern = f"{prefix}:route:{route_name}:*"
                keys = list(client.scan_iter(match=pattern))
                
                references = []
                threshold = 0.5
                
                for key in keys:
                    data = client.get(key)
                    if data:
                        entry = json.loads(data)
                        references.append(entry['reference'])
                        threshold = entry.get('threshold', 0.5)
                
                routes.append(Route(
                    name=route_name,
                    references=references,
                    threshold=threshold
                ))
            
            return cls(name=name, routes=routes, redis_client=client, **kwargs)
        except Exception as e:
            raise RuntimeError(f"从现有索引创建失败: {e}")
    
    @property
    def route_names(self) -> List[str]:
        """获取所有路由名称"""
        return [r.name for r in self.routes]
    
    @property
    def route_thresholds(self) -> Dict[str, Optional[float]]:
        """获取所有路由阈值"""
        return {r.name: r.distance_threshold for r in self.routes}
    
    def disconnect(self) -> None:
        """断开 Redis 连接"""
        if self._redis_client:
            self._redis_client.close()
            self._redis_client = None
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.disconnect()


def create_semantic_router(
    name: str,
    routes: List[Dict[str, Any]],
    redis_url: str = "redis://localhost:6379"
) -> SemanticRouter:
    """
    创建语义路由器的工厂函数
    
    Args:
        name: 路由器名称
        routes: 路由字典列表
        redis_url: Redis 连接 URL
        
    Returns:
        SemanticRouter 实例
    """
    route_objects = [
        Route(
            name=r['name'],
            references=r['references'],
            metadata=r.get('metadata', {}),
            distance_threshold=r.get('distance_threshold', 0.5)
        )
        for r in routes
    ]
    
    return SemanticRouter(
        name=name,
        routes=route_objects,
        redis_url=redis_url
    )
