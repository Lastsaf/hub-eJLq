"""
RedisVL Semantics - 语义处理模块

基于 Redis Vector Library 设计的高性能语义处理组件，
用于 AI 应用中的缓存、记忆和路由功能。

主要模块:
    - EmbeddingsCache: 嵌入向量缓存
    - SemanticCache: 语义缓存（LLM响应缓存）
    - SemanticMessageHistory: 语义消息历史
    - SemanticRouter: 语义路由器

安装依赖:
    pip install redis sentence-transformers

快速开始:
    from semantic_cache import SemanticCache
    
    cache = SemanticCache(
        name="llmcache",
        distance_threshold=0.1,
        ttl=360,
        redis_url="redis://localhost:6379"
    )
    
    # 存储
    cache.store("What is Python?", "Python is a programming language.")
    
    # 检查
    result = cache.check("Tell me about Python")
    if result:
        print(f"命中缓存: {result[0]['response']}")
"""

from .EmbeddingsCache import EmbeddingsCache
from .SemanticCache import SemanticCache
from .SemanticMessageHistory import SemanticMessageHistory
from .SemanticRouter import SemanticRouter, Route, RouteMatch, RoutingConfig

__version__ = "0.1.0"

__all__ = [
    "EmbeddingsCache",
    "SemanticCache",
    "SemanticMessageHistory",
    "SemanticRouter",
    "Route",
    "RouteMatch",
    "RoutingConfig",
]
