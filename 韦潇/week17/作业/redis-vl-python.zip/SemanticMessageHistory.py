"""
SemanticMessageHistory - 语义消息历史模块

基于语义相似度管理对话历史，支持智能筛选相关的历史消息，
而非简单按时间顺序。为 LLM 提供上下文丰富的对话记忆。

基于 Redis Vector Library (RedisVL) 设计
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import json
import uuid


class SemanticMessageHistory:
    """
    语义消息历史类
    
    存储和管理对话历史，支持按时间顺序和语义相似度检索。
    用于为 LLM 提供会话上下文和长期记忆。
    
    Attributes:
        name: 历史记录名称
        session_tag: 会话标签，用于关联特定对话
        distance_threshold: 语义距离阈值
        redis_client: Redis 客户端
    """
    
    # 支持的消息角色
    VALID_ROLES = {'system', 'user', 'llm', 'tool'}
    
    def __init__(
        self,
        name: str,
        session_tag: Optional[str] = None,
        prefix: Optional[str] = None,
        vectorizer=None,
        distance_threshold: float = 0.3,
        redis_client=None,
        redis_url: str = "redis://localhost:6379",
        connection_kwargs: Dict[str, Any] = {},
        overwrite: bool = False,
        **kwargs
    ):
        """
        初始化语义消息历史
        
        Args:
            name: 历史记录名称
            session_tag: 会话标签，默认使用 ULID
            prefix: Redis 键前缀
            vectorizer: 向量化器
            distance_threshold: 语义距离阈值，默认 0.3
            redis_client: Redis 客户端实例
            redis_url: Redis 连接 URL
            connection_kwargs: Redis 连接参数
            overwrite: 是否覆盖已有索引
        """
        self.name = name
        self.prefix = prefix or name
        self.session_tag = session_tag or self._generate_ulid()
        self.distance_threshold = distance_threshold
        self.vectorizer = vectorizer
        self.overwrite = overwrite
        self.redis_url = redis_url
        self.connection_kwargs = connection_kwargs
        self._redis_client = redis_client
        self._messages = []
        
        # 缓存键前缀
        self._prefix = f"msg_history:{self.prefix}"
        
        # 初始化
        if self._redis_client is None:
            self._init_redis_client()
        
        if self.vectorizer is None:
            self._init_vectorizer()
    
    def _init_redis_client(self):
        """初始化 Redis 客户端"""
        try:
            import redis
            self._redis_client = redis.from_url(
                self.redis_url,
                decode_responses=True,
                **self.connection_kwargs
            )
        except ImportError:
            raise ImportError("请安装 redis 包: pip install redis")
    
    def _init_vectorizer(self):
        """初始化向量化器"""
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer('all-MiniLM-L6-v2')
            self.vectorizer = self._embed_text
        except ImportError:
            raise ImportError("请安装 sentence-transformers 包: pip install sentence-transformers")
    
    def _embed_text(self, text: str) -> List[float]:
        """将文本转换为向量"""
        if hasattr(self, '_model'):
            embedding = self._model.encode(text)
            return embedding.tolist()
        raise RuntimeError("向量化器未初始化")
    
    def _generate_ulid(self) -> str:
        """生成 ULID"""
        try:
            from ulid import ULID
            return str(ULID())
        except ImportError:
            # 使用时间戳 + UUID 作为后备
            import time
            return f"{int(time.time() * 1000)}-{uuid.uuid4().hex[:12]}"
    
    def _generate_id(self) -> str:
        """生成唯一 ID"""
        return str(uuid.uuid4())
    
    def _validate_role(self, role: str) -> bool:
        """验证角色是否有效"""
        return role in self.VALID_ROLES
    
    def _validate_roles(self, roles: Union[str, List[str]]) -> None:
        """验证角色列表"""
        if isinstance(roles, str):
            roles = [roles]
        
        invalid = [r for r in roles if not self._validate_role(r)]
        if invalid:
            raise ValueError(f"无效的角色: {invalid}，有效角色: {self.VALID_ROLES}")
    
    def add_message(
        self,
        message: Dict[str, str],
        session_tag: Optional[str] = None
    ) -> None:
        """
        添加单条消息到历史记录
        
        Args:
            message: 消息字典，包含 'role' 和 'content'
            session_tag: 会话标签
            
        Raises:
            ValueError: 如果消息格式不正确或角色无效
        """
        if 'role' not in message or 'content' not in message:
            raise ValueError("消息必须包含 'role' 和 'content' 字段")
        
        role = message['role']
        if not self._validate_role(role):
            raise ValueError(f"无效的角色: {role}，有效角色: {self.VALID_ROLES}")
        
        content = message['content']
        metadata = message.get('metadata', {})
        tag = session_tag or self.session_tag
        
        # 生成向量
        vector = self.vectorizer(content)
        
        # 生成 ID
        entry_id = self._generate_id()
        
        # 存储数据
        entry = {
            'id': entry_id,
            'role': role,
            'content': content,
            'vector': vector,
            'metadata': metadata,
            'session_tag': tag,
            'timestamp': datetime.now().isoformat()
        }
        
        # Redis 存储
        key = f"{self._prefix}:{entry_id}"
        self._redis_client.set(key, json.dumps(entry))
        
        # 添加到有序集合（按时间排序）
        score = datetime.now().timestamp()
        self._redis_client.zadd(f"{self._prefix}:index:{tag}", {key: score})
        
        # 更新内存缓存
        self._messages.append(entry)
    
    def add_messages(
        self,
        messages: List[Dict[str, str]],
        session_tag: Optional[str] = None
    ) -> None:
        """
        批量添加消息到历史记录
        
        Args:
            messages: 消息字典列表
            session_tag: 会话标签
        """
        for message in messages:
            self.add_message(message, session_tag)
    
    def store(
        self,
        prompt: str,
        response: str,
        session_tag: Optional[str] = None
    ) -> None:
        """
        存储 prompt:response 对
        
        Args:
            prompt: 用户提示
            response: LLM 响应
            session_tag: 会话标签
        """
        tag = session_tag or self.session_tag
        
        self.add_message({'role': 'user', 'content': prompt}, tag)
        self.add_message({'role': 'llm', 'content': response}, tag)
    
    def get_recent(
        self,
        top_k: int = 5,
        as_text: bool = False,
        raw: bool = False,
        session_tag: Optional[str] = None,
        role: Optional[Union[str, List[str]]] = None
    ) -> Union[str, List[str]]:
        """
        获取最近的消息历史（按时间顺序）
        
        Args:
            top_k: 返回的消息数量
            as_text: 是否返回文本格式
            raw: 是否返回完整的 Redis 哈希
            session_tag: 会话标签
            role: 按角色过滤
            
        Returns:
            消息列表或文本字符串
            
        Raises:
            ValueError: 如果 top_k < 0 或角色无效
        """
        if top_k < 0:
            raise ValueError("top_k 必须 >= 0")
        
        if role is not None:
            self._validate_roles(role if isinstance(role, list) else [role])
        
        tag = session_tag or self.session_tag
        
        try:
            # 从有序集合获取
            index_key = f"{self._prefix}:index:{tag}"
            entries = self._redis_client.zrevrange(index_key, 0, top_k - 1)
            
            messages = []
            for key in entries:
                data = self._redis_client.get(key)
                if data:
                    entry = json.loads(data)
                    
                    # 角色过滤
                    if role:
                        roles = [role] if isinstance(role, str) else role
                        if entry['role'] not in roles:
                            continue
                    
                    if raw:
                        messages.append(entry)
                    else:
                        messages.append({
                            'role': entry['role'],
                            'content': entry['content'],
                            'metadata': entry.get('metadata', {})
                        })
            
            if as_text:
                return self._format_as_text(messages)
            return messages
        except Exception as e:
            print(f"获取最近消息失败: {e}")
            return [] if not as_text else ""
    
    def get_relevant(
        self,
        prompt: str,
        as_text: bool = False,
        top_k: int = 5,
        fall_back: bool = False,
        session_tag: Optional[str] = None,
        raw: bool = False,
        distance_threshold: Optional[float] = None,
        role: Optional[Union[str, List[str]]] = None
    ) -> Union[List[str], List[Dict[str, str]]]:
        """
        语义搜索相关消息
        
        Args:
            prompt: 搜索文本
            as_text: 是否返回文本格式
            top_k: 返回的消息数量
            fall_back: 是否在无结果时回退到最近消息
            session_tag: 会话标签
            raw: 是否返回完整的 Redis 哈希
            distance_threshold: 语义距离阈值
            role: 按角色过滤
            
        Returns:
            相关消息列表
            
        Raises:
            ValueError: 如果 top_k < 0 或角色无效
        """
        if top_k < 0:
            raise ValueError("top_k 必须 >= 0")
        
        if role is not None:
            self._validate_roles(role if isinstance(role, list) else [role])
        
        threshold = distance_threshold or self.distance_threshold
        tag = session_tag or self.session_tag
        
        # 生成查询向量
        query_vector = self.vectorizer(prompt)
        
        try:
            # 获取所有消息并计算相似度
            index_key = f"{self._prefix}:index:{tag}"
            all_keys = self._redis_client.zrange(index_key, 0, -1)
            
            results = []
            for key in all_keys:
                data = self._redis_client.get(key)
                if data:
                    entry = json.loads(data)
                    
                    # 角色过滤
                    if role:
                        roles = [role] if isinstance(role, str) else role
                        if entry['role'] not in roles:
                            continue
                    
                    # 计算距离
                    distance = self._cosine_distance(
                        query_vector,
                        entry.get('vector', [])
                    )
                    
                    if distance <= threshold:
                        result = {
                            **entry,
                            'distance': distance
                        }
                        results.append(result)
            
            # 按距离排序
            results.sort(key=lambda x: x['distance'])
            results = results[:top_k]
            
            if not results and fall_back:
                return self.get_recent(
                    top_k=top_k,
                    as_text=as_text,
                    raw=raw,
                    session_tag=session_tag,
                    role=role
                )
            
            if raw:
                return results
            else:
                formatted = [
                    {
                        'role': r['role'],
                        'content': r['content'],
                        'metadata': r.get('metadata', {})
                    }
                    for r in results
                ]
                
                if as_text:
                    return self._format_as_text(formatted)
                return formatted
                
        except Exception as e:
            print(f"语义搜索失败: {e}")
            if fall_back:
                return self.get_recent(
                    top_k=top_k,
                    as_text=as_text,
                    raw=raw,
                    session_tag=session_tag,
                    role=role
                )
            return []
    
    def _cosine_distance(self, v1: List[float], v2: List[float]) -> float:
        """计算余弦距离"""
        if not v1 or not v2 or len(v1) != len(v2):
            return 2.0
        
        dot_product = sum(a * b for a, b in zip(v1, v2))
        norm1 = sum(a * a for a in v1) ** 0.5
        norm2 = sum(b * b for b in v2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 2.0
        
        similarity = dot_product / (norm1 * norm2)
        return 1.0 - similarity
    
    def _format_as_text(self, messages: List[Dict[str, Any]]) -> str:
        """格式化消息为文本"""
        lines = []
        for msg in messages:
            role = msg.get('role', 'unknown')
            content = msg.get('content', '')
            lines.append(f"{role.upper()}: {content}")
        return "\n".join(lines)
    
    def count(self, session_tag: Optional[str] = None) -> int:
        """
        统计消息数量
        
        Args:
            session_tag: 会话标签
            
        Returns:
            消息数量
        """
        tag = session_tag or self.session_tag
        index_key = f"{self._prefix}:index:{tag}"
        return self._redis_client.zcard(index_key)
    
    def clear(self) -> None:
        """清空当前会话的消息"""
        index_key = f"{self._prefix}:index:{self.session_tag}"
        keys = self._redis_client.zrange(index_key, 0, -1)
        
        if keys:
            self._redis_client.delete(*keys)
        self._redis_client.delete(index_key)
        self._messages = []
    
    def delete(self) -> None:
        """删除所有会话消息和索引"""
        pattern = f"{self._prefix}:*"
        keys = list(self._redis_client.scan_iter(match=pattern))
        if keys:
            self._redis_client.delete(*keys)
        self._messages = []
    
    def drop(self, id: Optional[str] = None) -> None:
        """
        删除特定消息
        
        Args:
            id: 消息 ID，如果为 None 则删除最后一条
        """
        if id is None:
            # 获取最后一条
            index_key = f"{self._prefix}:index:{self.session_tag}"
            keys = self._redis_client.zrange(index_key, -1, -1)
            if keys:
                id = keys[0].split(':')[-1]
        
        if id:
            key = f"{self._prefix}:{id}"
            self._redis_client.delete(key)
            
            # 从索引中移除
            index_key = f"{self._prefix}:index:{self.session_tag}"
            self._redis_client.zrem(index_key, key)
            
            # 从内存中移除
            self._messages = [m for m in self._messages if m.get('id') != id]
    
    @property
    def messages(self) -> List[Dict[str, str]]:
        """
        获取完整的消息历史
        
        Returns:
            消息列表
        """
        tag = self.session_tag
        index_key = f"{self._prefix}:index:{tag}"
        
        try:
            keys = self._redis_client.zrange(index_key, 0, -1)
            messages = []
            for key in keys:
                data = self._redis_client.get(key)
                if data:
                    entry = json.loads(data)
                    messages.append({
                        'role': entry['role'],
                        'content': entry['content']
                    })
            return messages
        except Exception:
            return self._messages
    
    def disconnect(self) -> None:
        """断开 Redis 连接"""
        if self._redis_client:
            self._redis_client.close()
            self._redis_client = None
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.disconnect()


def create_message_history(
    name: str,
    session_tag: Optional[str] = None,
    distance_threshold: float = 0.3,
    redis_url: str = "redis://localhost:6379"
) -> SemanticMessageHistory:
    """
    创建消息历史的工厂函数
    
    Args:
        name: 历史记录名称
        session_tag: 会话标签
        distance_threshold: 语义距离阈值
        redis_url: Redis 连接 URL
        
    Returns:
        SemanticMessageHistory 实例
    """
    return SemanticMessageHistory(
        name=name,
        session_tag=session_tag,
        distance_threshold=distance_threshold,
        redis_url=redis_url
    )
