"""
SemanticCache - 语义缓存模块

基于语义相似度的 LLM 响应缓存系统。当用户提问与缓存中的问题
语义相似时，直接返回缓存的答案，减少 LLM 调用次数，降低成本。

基于 Redis Vector Library (RedisVL) 设计
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import json
import hashlib
import uuid


class SemanticCache:
    """
    语义缓存类
    
    使用向量相似度搜索来缓存和检索 LLM 响应。
    当新的提示与缓存中的提示语义相似时，返回缓存的响应。
    
    Attributes:
        name: 缓存名称
        distance_threshold: 语义距离阈值 [0-2]，值越小匹配越严格
        ttl: 过期时间（秒）
        vectorizer: 向量化器
        redis_client: Redis 客户端
    """
    
    def __init__(
        self,
        name: str = "llmcache",
        distance_threshold: float = 0.1,
        ttl: Optional[int] = None,
        vectorizer=None,
        filterable_fields: Optional[List[Dict[str, Any]]] = None,
        redis_client=None,
        redis_url: str = "redis://localhost:6379",
        connection_kwargs: Dict[str, Any] = {},
        overwrite: bool = False,
        **kwargs
    ):
        """
        初始化语义缓存
        
        Args:
            name: 缓存名称，默认 "llmcache"
            distance_threshold: 语义距离阈值 [0-2]，默认 0.1
            ttl: 过期时间（秒），默认 None（永不过期）
            vectorizer: 向量化器，默认使用 HuggingFace 向量化器
            filterable_fields: 可过滤的字段列表
            redis_client: Redis 客户端实例
            redis_url: Redis 连接 URL
            connection_kwargs: Redis 连接参数
            overwrite: 是否覆盖已有索引
        """
        # 参数验证
        if not 0 <= distance_threshold <= 2:
            raise ValueError("distance_threshold 必须在 0-2 之间（Redis COSINE 距离）")
        
        if ttl is not None and not isinstance(ttl, int):
            raise TypeError("TTL 值必须是整数")
        
        self.name = name
        self.distance_threshold = distance_threshold
        self.ttl = ttl
        self.vectorizer = vectorizer
        self.filterable_fields = filterable_fields or []
        self.overwrite = overwrite
        self.redis_url = redis_url
        self.connection_kwargs = connection_kwargs
        self._redis_client = redis_client
        
        # 缓存键前缀
        self._prefix = f"llmcache:{name}"
        self._index_name = f"llmcache:{name}"
        
        # 初始化
        if self._redis_client is None:
            self._init_redis_client()
        
        # 初始化向量化器（如果未提供）
        if self.vectorizer is None:
            self._init_vectorizer()
    
    def _init_redis_client(self):
        """初始化 Redis 客户端"""
        try:
            import redis
            self._redis_client = redis.from_url(
                self.redis_url,
                decode_responses=True,
                **self.connection_kwargs
            )
        except ImportError:
            raise ImportError("请安装 redis 包: pip install redis")
    
    def _init_vectorizer(self):
        """初始化向量化器"""
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer('all-MiniLM-L6-v2')
            self.vectorizer = self._embed_text
        except ImportError:
            raise ImportError("请安装 sentence-transformers 包: pip install sentence-transformers")
    
    def _embed_text(self, text: str) -> List[float]:
        """
        将文本转换为向量
        
        Args:
            text: 输入文本
            
        Returns:
            向量列表
        """
        if hasattr(self, '_model'):
            embedding = self._model.encode(text)
            return embedding.tolist()
        raise RuntimeError("向量化器未初始化")
    
    def _generate_id(self) -> str:
        """生成唯一 ID"""
        return str(uuid.uuid4())
    
    def check(
        self,
        prompt: Optional[str] = None,
        vector: Optional[List[float]] = None,
        num_results: int = 1,
        return_fields: Optional[List[str]] = None,
        filter_expression=None,
        distance_threshold: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """
        检查语义缓存中是否存在相似的响应
        
        Args:
            prompt: 要搜索的文本提示
            vector: 提示的向量表示
            num_results: 返回的结果数量
            return_fields: 返回的字段列表
            filter_expression: 过滤表达式
            distance_threshold: 语义距离阈值
            
        Returns:
            匹配结果的列表
            
        Raises:
            ValueError: 如果既没有提供 prompt 也没有提供 vector
        """
        if prompt is None and vector is None:
            raise ValueError("必须提供 prompt 或 vector")
        
        # 获取向量
        if vector is None:
            vector = self.vectorizer(prompt)
        
        # 获取阈值
        threshold = distance_threshold or self.distance_threshold
        
        # 构建查询
        cache_key = self._generate_cache_key(vector)
        
        try:
            # 使用向量相似度搜索
            results = self._vector_search(
                vector=vector,
                threshold=threshold,
                num_results=num_results,
                return_fields=return_fields
            )
            
            return results
        except Exception as e:
            print(f"语义缓存查询失败: {e}")
            return []
    
    async def acheck(
        self,
        prompt: Optional[str] = None,
        vector: Optional[List[float]] = None,
        num_results: int = 1,
        return_fields: Optional[List[str]] = None,
        filter_expression=None,
        distance_threshold: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """异步版本的 check 方法"""
        return self.check(
            prompt=prompt,
            vector=vector,
            num_results=num_results,
            return_fields=return_fields,
            filter_expression=filter_expression,
            distance_threshold=distance_threshold
        )
    
    def _generate_cache_key(self, vector: List[float]) -> str:
        """生成基于向量的缓存键"""
        vector_str = json.dumps(vector)
        return hashlib.md5(vector_str.encode()).hexdigest()
    
    def _vector_search(
        self,
        vector: List[float],
        threshold: float,
        num_results: int,
        return_fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        执行向量相似度搜索
        
        Args:
            vector: 查询向量
            threshold: 距离阈值
            num_results: 结果数量
            return_fields: 返回字段
            
        Returns:
            搜索结果列表
        """
        try:
            # 尝试使用 Redis Search 模块
            from redis.commands.search.query import Query
            
            # 构建查询
            q = Query(f"*=>[KNN {num_results} @vector $vector AS score]")
            q.sort_by("score")
            q.filter(f"@score:[0 {threshold}]")
            
            # 执行搜索
            results = self._redis_client.ft(self._index_name).search(
                q,
                query_params={"vector": vector}
            )
            
            return [
                {
                    "prompt": doc.prompt,
                    "response": doc.response,
                    "metadata": json.loads(doc.metadata) if hasattr(doc, 'metadata') else {},
                    "distance": float(doc.score) if hasattr(doc, 'score') else 0.0
                }
                for doc in results.docs
            ]
        except Exception as e:
            # 如果使用简单的哈希键存储，回退到扫描方式
            return self._fallback_search(vector, threshold, num_results)
    
    def _fallback_search(
        self,
        vector: List[float],
        threshold: float,
        num_results: int
    ) -> List[Dict[str, Any]]:
        """简单回退搜索方法"""
        try:
            pattern = f"{self._prefix}:*"
            keys = list(self._redis_client.scan_iter(match=pattern, count=100))
            
            results = []
            for key in keys:
                cached = self._redis_client.get(key)
                if cached:
                    data = json.loads(cached)
                    cached_vector = data.get('vector', [])
                    distance = self._cosine_distance(vector, cached_vector)
                    
                    if distance <= threshold:
                        results.append({
                            'prompt': data.get('prompt'),
                            'response': data.get('response'),
                            'metadata': data.get('metadata', {}),
                            'distance': distance
                        })
            
            # 按距离排序
            results.sort(key=lambda x: x['distance'])
            return results[:num_results]
        except Exception as e:
            print(f"回退搜索失败: {e}")
            return []
    
    def _cosine_distance(self, v1: List[float], v2: List[float]) -> float:
        """计算余弦距离"""
        if not v1 or not v2 or len(v1) != len(v2):
            return 2.0  # 最大距离
        
        dot_product = sum(a * b for a, b in zip(v1, v2))
        norm1 = sum(a * a for a in v1) ** 0.5
        norm2 = sum(b * b for b in v2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 2.0
        
        similarity = dot_product / (norm1 * norm2)
        return 1.0 - similarity  # 转换为距离
    
    def store(
        self,
        prompt: str,
        response: str,
        vector: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        filters: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None
    ) -> str:
        """
        存储提示和响应到语义缓存
        
        Args:
            prompt: 用户提示
            response: LLM 响应
            vector: 提示的向量表示
            metadata: 可选的元数据
            filters: 可选的过滤标签
            ttl: 单独的 TTL 覆盖
            
        Returns:
            Redis 键
            
        Raises:
            ValueError: 如果没有提供 prompt
        """
        if not prompt:
            raise ValueError("必须提供 prompt")
        
        # 生成向量
        if vector is None:
            vector = self.vectorizer(prompt)
        
        # 生成 ID 和键
        entry_id = self._generate_id()
        cache_key = f"{self._prefix}:{entry_id}"
        
        # 存储数据
        cache_data = {
            'id': entry_id,
            'prompt': prompt,
            'response': response,
            'vector': vector,
            'metadata': metadata or {},
            'filters': filters or {},
            'created_at': datetime.now().isoformat()
        }
        
        # 确定 TTL
        entry_ttl = ttl or self.ttl
        
        try:
            if entry_ttl:
                self._redis_client.setex(
                    cache_key,
                    entry_ttl,
                    json.dumps(cache_data)
                )
            else:
                self._redis_client.set(cache_key, json.dumps(cache_data))
            
            return cache_key
        except Exception as e:
            print(f"存储缓存失败: {e}")
            return cache_key
    
    async def astore(
        self,
        prompt: str,
        response: str,
        vector: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        filters: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None
    ) -> str:
        """异步版本的 store 方法"""
        return self.store(
            prompt=prompt,
            response=response,
            vector=vector,
            metadata=metadata,
            filters=filters,
            ttl=ttl
        )
    
    def clear(self) -> None:
        """清空缓存"""
        try:
            pattern = f"{self._prefix}:*"
            keys = list(self._redis_client.scan_iter(match=pattern))
            if keys:
                self._redis_client.delete(*keys)
        except Exception as e:
            print(f"清空缓存失败: {e}")
    
    async def aclear(self) -> None:
        """异步版本的 clear 方法"""
        self.clear()
    
    def delete(self) -> None:
        """删除整个缓存和索引"""
        self.clear()
        try:
            self._redis_client.delete(self._index_name)
        except Exception:
            pass
    
    async def adelete(self) -> None:
        """异步版本的 delete 方法"""
        self.delete()
    
    def drop(self, ids: Optional[List[str]] = None, keys: Optional[List[str]] = None) -> None:
        """
        删除特定的缓存条目
        
        Args:
            ids: 条目 ID 列表
            keys: 完整的 Redis 键列表
        """
        if ids is None and keys is None:
            raise ValueError("必须提供 ids 或 keys")
        
        try:
            keys_to_delete = []
            
            if ids:
                keys_to_delete.extend([f"{self._prefix}:{id}" for id in ids])
            
            if keys:
                keys_to_delete.extend(keys)
            
            if keys_to_delete:
                self._redis_client.delete(*keys_to_delete)
        except Exception as e:
            print(f"删除缓存条目失败: {e}")
    
    async def adrop(self, ids: Optional[List[str]] = None, keys: Optional[List[str]] = None) -> None:
        """异步版本的 drop 方法"""
        self.drop(ids=ids, keys=keys)
    
    def update(self, key: str, **kwargs) -> None:
        """
        更新缓存条目
        
        Args:
            key: 缓存键
            **kwargs: 要更新的字段
        """
        try:
            data = self._redis_client.get(key)
            if data:
                entry = json.loads(data)
                entry.update(kwargs)
                self._redis_client.set(key, json.dumps(entry))
        except Exception as e:
            print(f"更新缓存失败: {e}")
    
    async def aupdate(self, key: str, **kwargs) -> None:
        """异步版本的 update 方法"""
        self.update(key, **kwargs)
    
    def set_threshold(self, distance_threshold: float) -> None:
        """
        设置语义距离阈值
        
        Args:
            distance_threshold: 新的阈值 [0-2]
        """
        if not 0 <= distance_threshold <= 2:
            raise ValueError("阈值必须在 0-2 之间")
        self.distance_threshold = distance_threshold
    
    def set_ttl(self, ttl: Optional[int]) -> None:
        """
        设置默认 TTL
        
        Args:
            ttl: 过期时间（秒）
        """
        if ttl is not None and not isinstance(ttl, int):
            raise ValueError("TTL 必须是整数")
        self.ttl = ttl
    
    def disconnect(self) -> None:
        """断开 Redis 连接"""
        if self._redis_client:
            self._redis_client.close()
            self._redis_client = None
    
    async def adisconnect(self) -> None:
        """异步版本的 disconnect 方法"""
        self.disconnect()
    
    @property
    def index(self):
        """获取底层搜索索引"""
        return self._index_name
    
    @property
    def ttl(self) -> Optional[int]:
        """获取 TTL"""
        return self._ttl
    
    @ttl.setter
    def ttl(self, value: Optional[int]):
        """设置 TTL"""
        self._ttl = value
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.disconnect()


def create_semantic_cache(
    name: str = "llmcache",
    distance_threshold: float = 0.1,
    ttl: int = 360,
    redis_url: str = "redis://localhost:6379"
) -> SemanticCache:
    """
    创建语义缓存的工厂函数
    
    Args:
        name: 缓存名称
        distance_threshold: 语义距离阈值
        ttl: 过期时间
        redis_url: Redis 连接 URL
        
    Returns:
        SemanticCache 实例
    """
    return SemanticCache(
        name=name,
        distance_threshold=distance_threshold,
        ttl=ttl,
        redis_url=redis_url
    )
