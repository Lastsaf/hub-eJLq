"""
EmbeddingsCache - 嵌入向量缓存模块

用于缓存文本的向量表示，避免重复调用嵌入模型生成向量，
节省 API 调用成本和时间。

基于 Redis Vector Library (RedisVL) 设计
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import json
import hashlib


class EmbeddingsCache:
    """
    嵌入向量缓存类
    
    通过 Redis 存储和检索嵌入向量，支持 TTL 过期时间管理。
    当文本相同时，直接返回缓存的向量，避免重复计算。
    
    Attributes:
        name: 缓存名称
        ttl: 过期时间（秒）
        vectorizer: 向量化器
        redis_client: Redis 客户端
        redis_url: Redis 连接 URL
    """
    
    def __init__(
        self,
        name: str = "embed_cache",
        ttl: Optional[int] = 3600,
        redis_client=None,
        redis_url: str = "redis://localhost:6379",
        connection_kwargs: Dict[str, Any] = {},
        **kwargs
    ):
        """
        初始化嵌入缓存
        
        Args:
            name: 缓存名称，默认 "embed_cache"
            ttl: 过期时间（秒），默认 3600（1小时）
            redis_client: Redis 客户端实例
            redis_url: Redis 连接 URL
            connection_kwargs: Redis 连接参数
        """
        self.name = name
        self.ttl = ttl
        self.redis_url = redis_url
        self.connection_kwargs = connection_kwargs
        self._redis_client = redis_client
        
        # 缓存键前缀
        self._prefix = f"embed_cache:{name}"
        
        # 初始化 Redis 客户端（如果未提供）
        if self._redis_client is None:
            self._init_redis_client()
    
    def _init_redis_client(self):
        """初始化 Redis 客户端"""
        try:
            import redis
            self._redis_client = redis.from_url(
                self.redis_url,
                decode_responses=True,
                **self.connection_kwargs
            )
        except ImportError:
            raise ImportError("请安装 redis 包: pip install redis")
    
    def _generate_cache_key(self, text: str) -> str:
        """
        生成缓存键
        
        Args:
            text: 输入文本
            
        Returns:
            缓存键（基于文本的 MD5 哈希）
        """
        text_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
        return f"{self._prefix}:{text_hash}"
    
    def get(self, text: str) -> Optional[List[float]]:
        """
        获取缓存的嵌入向量
        
        Args:
            text: 输入文本
            
        Returns:
            缓存的向量列表，如果不存在则返回 None
        """
        cache_key = self._generate_cache_key(text)
        
        try:
            cached_data = self._redis_client.get(cache_key)
            if cached_data:
                data = json.loads(cached_data)
                return data.get('vector')
            return None
        except Exception as e:
            print(f"获取缓存失败: {e}")
            return None
    
    def set(
        self,
        text: str,
        vector: List[float],
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        设置嵌入向量缓存
        
        Args:
            text: 输入文本
            vector: 向量列表
            metadata: 可选的元数据
            
        Returns:
            缓存键
        """
        cache_key = self._generate_cache_key(text)
        
        cache_data = {
            'text': text,
            'vector': vector,
            'metadata': metadata or {},
            'created_at': datetime.now().isoformat()
        }
        
        try:
            self._redis_client.setex(
                cache_key,
                self.ttl,
                json.dumps(cache_data)
            )
            return cache_key
        except Exception as e:
            print(f"设置缓存失败: {e}")
            return cache_key
    
    def check(self, text: str) -> Optional[List[float]]:
        """
        检查缓存中是否存在向量（别名方法）
        
        Args:
            text: 输入文本
            
        Returns:
            缓存的向量列表，如果不存在则返回 None
        """
        return self.get(text)
    
    def delete(self, text: str) -> bool:
        """
        删除缓存的向量
        
        Args:
            text: 输入文本
            
        Returns:
            是否删除成功
        """
        cache_key = self._generate_cache_key(text)
        
        try:
            result = self._redis_client.delete(cache_key)
            return result > 0
        except Exception as e:
            print(f"删除缓存失败: {e}")
            return False
    
    def clear(self) -> int:
        """
        清空所有缓存
        
        Returns:
            删除的键数量
        """
        try:
            pattern = f"{self._prefix}:*"
            keys = list(self._redis_client.scan_iter(match=pattern))
            if keys:
                return self._redis_client.delete(*keys)
            return 0
        except Exception as e:
            print(f"清空缓存失败: {e}")
            return 0
    
    def get_many(self, texts: List[str]) -> Dict[str, Optional[List[float]]]:
        """
        批量获取缓存的嵌入向量
        
        Args:
            texts: 输入文本列表
            
        Returns:
            文本到向量的映射字典
        """
        result = {}
        for text in texts:
            result[text] = self.get(text)
        return result
    
    def set_many(
        self,
        items: List[Dict[str, Any]],
        texts_key: str = "text",
        vector_key: str = "vector"
    ) -> List[str]:
        """
        批量设置嵌入向量缓存
        
        Args:
            items: 包含文本和向量的字典列表
            texts_key: 文本字段名
            vector_key: 向量字段名
            
        Returns:
            缓存键列表
        """
        keys = []
        for item in items:
            text = item.get(texts_key, "")
            vector = item.get(vector_key, [])
            if text and vector:
                key = self.set(text, vector)
                keys.append(key)
        return keys
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计信息
        
        Returns:
            缓存统计信息字典
        """
        try:
            pattern = f"{self._prefix}:*"
            keys = list(self._redis_client.scan_iter(match=pattern))
            
            total_size = 0
            for key in keys:
                size = self._redis_client.strlen(key)
                total_size += size
            
            return {
                'name': self.name,
                'ttl': self.ttl,
                'total_entries': len(keys),
                'total_size_bytes': total_size,
                'prefix': self._prefix
            }
        except Exception as e:
            print(f"获取统计失败: {e}")
            return {}
    
    def disconnect(self):
        """断开 Redis 连接"""
        if self._redis_client:
            self._redis_client.close()
            self._redis_client = None
    
    @property
    def redis_client(self):
        """获取 Redis 客户端"""
        return self._redis_client
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.disconnect()


def create_embeddings_cache(
    name: str = "embed_cache",
    ttl: int = 3600,
    redis_url: str = "redis://localhost:6379"
) -> EmbeddingsCache:
    """
    创建嵌入缓存的工厂函数
    
    Args:
        name: 缓存名称
        ttl: 过期时间
        redis_url: Redis 连接 URL
        
    Returns:
        EmbeddingsCache 实例
    """
    return EmbeddingsCache(
        name=name,
        ttl=ttl,
        redis_url=redis_url
    )
